//function with return type


#include <iostream>

using namespace std;

int Abc(){
    cout<<"Function with return type int"<<endl;
    
    return 1;
}

int main()
{
    int x;
  
    x = Abc();
    cout<<x;

    return 0;
    
    
}


