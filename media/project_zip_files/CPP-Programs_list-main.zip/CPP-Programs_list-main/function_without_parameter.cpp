
#include <iostream>

using namespace std;

void Fun(){
    cout<<"Function without parameter"<<endl;
}


int main()
{
    Fun();

    return 0;
}
