#include <iostream>

using namespace std;

int main()
{
   int i;
   cout<<"Enter value of i :";
   cin>>i;
   if(i==0){
       cout<<"zero";
   }
    else{
        cout<<"Non Zero";
    }
    return 0;
}
